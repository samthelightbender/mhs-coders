import { AppCardNewPost } from "@/components/ui/app-card-new-post";

export default function Home() {
  return (
    <div className="mx-2 mt-2">
      <AppCardNewPost />
    </div>
  );
}